package main

func main() {
	s := ""
	t := "test"
	panic("panic!!!")
	println(s, t)
}
