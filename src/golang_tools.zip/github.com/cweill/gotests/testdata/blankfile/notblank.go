package blankfile

import "os"

func Not(this *os.File) string { return "not this file" }
