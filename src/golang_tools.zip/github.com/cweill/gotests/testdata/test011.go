package testdata

func Foo11(strs []string) ([]*Bar, error) { return nil, nil }
