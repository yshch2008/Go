package testdata

func Foo12(str string) error { return nil }
