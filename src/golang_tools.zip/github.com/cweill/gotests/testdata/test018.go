package testdata

import "os"

func Foo18(t *os.File) *os.File { return t }
