package testdata

func (b *Bar) Foo7(i int) (string, error) { return "", nil }
